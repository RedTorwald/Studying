﻿using I1f;
using System;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.Intrinsics.X86;

namespace I1f
{

    public class Work
    {
       
        public static string Decide(int n)
        {
            int a=0;
            int b=0;
            string msg="";
            string msg1 = "";
           
            string outMessage= "";
            
            if ((n > 1) && (n < 9999))
            {
                a = n / 100;

                if (a % 100 >= 11 && a % 100 <= 19 ) { msg = "рублей"; }
                else if (a % 10 == 1){msg = "рубль";}
                else if (a%10 >= 2  && a%10 <= 4) { msg = "рубля"; }
                else { msg = "рублей"; }

                b = n % 100; 
                if (b % 100 >= 11 && b % 100 <= 19 ) { msg1 = "копеек"; }
                else if (b % 10 == 1){msg1 = "копейка";}
                else if (b%10 >= 2  && b%10 <= 4) { msg1 = "копейки"; }
                else { msg1 = "копеек"; }
                outMessage=a+" "+msg+" "+b+" "+msg1;
            }
            else
            {
                outMessage="введённое значение не находится в промежутке (1, 9999)";
            }                        
            return outMessage;
        } 
        
    } 
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Ввод данных");
            var n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(Work.Decide(n));
        }
    }
}
