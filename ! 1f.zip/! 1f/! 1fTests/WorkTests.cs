﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using I1f;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace I1f.Tests
{
    [TestClass()]
    public class WorkTests
    {
        [TestMethod()]
        public void DecideTest()
        {
        var n = 8888;                     
        Assert.AreEqual( "88 рублей 88 копеек" , Work.Decide(n));    
        }

        [TestMethod()]
        public void Error1()
        {
        var n = 1;                     
        Assert.AreEqual( "введённое значение не находится в промежутке (1, 9999)" , Work.Decide(n));                
        }
        
        [TestMethod()]
        public void Error()
        {
        var n = 10000;                     
        Assert.AreEqual( "введённое значение не находится в промежутке (1, 9999)" , Work.Decide(n));        
        }
        
        [TestMethod()]
        public void Error2()
        {
        var n = 1111;                     
        Assert.AreEqual( "11 рублей 11 копеек" , Work.Decide(n));        
        }
        
        [TestMethod()]
        public void DecideTest3()
        {
        var n = 4520;                     
        Assert.AreEqual( "45 рублей 20 копеек" , Work.Decide(n));        
        }
        
    }
}
