﻿using Microsoft.VisualBasic;
using System;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp3
{
    public class Logic
    {       
        public static string Decide(int a, int b)
        {
            int counterA = 0;
            int counterB = 0;
            List<int> nums=new List<int>();
            string outMessage= "1) стороны квадратов: |";

            if (a==b){ outMessage="Введён квадрат";}
            while (a!=b)
            {
                if (a<b)
                {
                    b-=a;
                    counterA++;                    
                    nums.Add(a);
                }
                else
                {
                    a-=b;
                    counterB++;                   
                    nums.Add(b);
                }
                for (int i=0; i<nums.Count; i++)
                {
                     outMessage+=nums[i];
                     outMessage+="|";
                }               
            }
            outMessage+=" 2) количество квадратов: "+Convert.ToString(counterA+counterB+1);
            return outMessage;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
             Console.WriteLine("Введите a, b - стороны квадрата");    
             int a = int.Parse(Console.ReadLine());
             int b = int.Parse(Console.ReadLine());
             
             Console.WriteLine(Logic.Decide(a, b));
        }
    }
}