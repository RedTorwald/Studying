﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Tests
{
    [TestClass()]
    public class LogicTests
    {
        [TestMethod()]
        public void DecideTest()
        {
        var a = 8;
        var b = 6;                
        Assert.AreEqual("1) стороны квадратов: |6|6|2|6|2|2| 2) количество квадратов: 4",  Logic.Decide(a, b));
        }

        [TestMethod()]
        public void DecideTest1()
        {
        var a = 25;
        var b = 9;                
        Assert.AreEqual("1) стороны квадратов: |9|9|9|9|9|7|9|9|7|2|9|9|7|2|2|9|9|7|2|2|2|9|9|7|2|2|2|1| 2) количество квадратов: 8",  Logic.Decide(a, b));
        }
        
        [TestMethod()]
        public void DecideTest2()
        {
        var a = 8;
        var b = 15;                
        Assert.AreEqual("1) стороны квадратов: |8|8|7|8|7|1|8|7|1|1|8|7|1|1|1|8|7|1|1|1|1|8|7|1|1|1|1|1|8|7|1|1|1|1|1|1| 2) количество квадратов: 9",  Logic.Decide(a, b));
        }

        [TestMethod()]
        public void DecideTest4()
        {
        var a = 13;
        var b = 37;                
        Assert.AreEqual("1) стороны квадратов: |13|13|13|13|13|11|13|13|11|2|13|13|11|2|2|13|13|11|2|2|2|13|13|11|2|2|2|2|13|13|11|2|2|2|2|2|13|13|11|2|2|2|2|2|1| 2) количество квадратов: 10",  Logic.Decide(a, b));
        }
        [TestMethod()]
        public void DecideTest5()
        {
        var a = 3;
        var b = 2;                
        Assert.AreEqual("1) стороны квадратов: |2|2|1| 2) количество квадратов: 3",  Logic.Decide(a, b));
        }
    }
}