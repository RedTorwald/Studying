﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace strings
{
    public class Logic
    {
        
        public static string Decide(string str)
        {
            int sum=0;
            int check=0;
            //string str="5+2-1+3-1";
            sum=str[0]-'0';
            string outMessage=""; 
        
            for (int i=1; i<str.Count(); i+=4)
            {
                if (str[i] == '+')
                {
                    if (str[i+1]>='1' && str[i+1]<='9')
                    {
                        sum+=str[i+1]-'0';
                        check=1;
                    }
                                
                }                
                else
                {   
                    check=3;                        
                }                
            }           
            if(check==3)
            {
                return "отсутствует чередование +";
            }

            for (int i=3; i<str.Count(); i+=4)
            {
                if (str[i] == '-')
                {
                    if (str[i+1]>='1' && str[i+1]<='9')
                    {
                        sum-=str[i+1]-'0';
                        check=2;
                    }                    
                }                
                else
                {
                    check=4;                      
                }                
            }            
            if(check==2)
            {
                outMessage+=sum;
            }
            else 
            {
                return "отсутствует чередование -";
            }            
        return  outMessage;
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            string? str = Console.ReadLine();
            Console.WriteLine( Logic.Decide(str));
        } 
    }
}

    
