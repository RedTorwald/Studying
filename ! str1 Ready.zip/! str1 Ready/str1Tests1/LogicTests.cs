﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using strings;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace strings.Tests
{
    [TestClass()]
    public class LogicTests
    {
        [TestMethod()]
        public void DecideTest()
        {

        string str = "5+2-1+3-1";
       
        Assert.AreEqual("8",Logic.Decide(str));

        }
     
        [TestMethod()]
        public void Test1()
        {

        string str = "9+9-8+9-8";
        
        Assert.AreEqual("11",Logic.Decide(str));

        }
        [TestMethod()]
        public void Test2()
        {

        string str = "2+2-8+1-4";
        Assert.AreEqual("-7",Logic.Decide(str));

        }
        [TestMethod()]
        public void Test3()
        {

        string str = "7+9-2+1-3";
        Assert.AreEqual("12",Logic.Decide(str));

        }
        [TestMethod()]
        public void Test4()
        {

        string str = "1+9-8+3-4";
        Assert.AreEqual("1",Logic.Decide(str));

        }
     
    }
}